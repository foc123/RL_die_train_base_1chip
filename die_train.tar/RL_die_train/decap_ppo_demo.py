"""
A new ckt environment based on a new structure of MDP
"""
import gym
from gym import spaces
import time 
import numpy as np
import random
import statistics
import os
import IPython
import itertools
import pickle
import os

NCOL, NROW, NCAP = 5, 5, 10
CAP_VAL = 1e-8
VDI_LOW = -1000.00
VDI_HIGH = 144.0
VDI_TARGET = 8e-10
NODE_LOC = [416, 1250, 2083, 2916, 3750, 4583, 5416, 6250, 7083, 7916, 8750, 9583]
PATH_PREFIX =  '/HDD8T/2021StudentFile/fhy/DQN/gitcode/duo_multi/duo-opt-RL10_source/'

multi = 10
vdi_max = 0.0
vdi_min = 100.0
dcap_max = 0.0
dcap_min = 100.0
dcap_offset = 1.0e-9    # decap leakage cost offset
dcap_threshold = 10.0e-9   # decap leakage cost threshold


global dict_state


def run_os():
        #global ST
    # first recreate pid+chiplet1_tr_new.subckt
    #power_choice()
    global p
    #xxx='''

    with open('source_choice','r') as f:
        line = f.readlines()
    f.close()

    if (str(os.getpid()) +'\n') not in line:
        with open('source_choice','a') as f:
            f.write(str(os.getpid())+'\n')
        f.close()

    with open('source_choice','r') as f:
        lns = f.readlines()
        idx = lns.index(str(os.getpid())+'\n')
        f.close()

    with open('power_source','r') as f1:
        s1 = f1.readlines()
        p = s1[1]
    f1.close()
  #'''
    subs = idx % multi
    filename = 'duo_tr_core1_dcap10_%d.subckt' % subs
    with open(PATH_PREFIX + filename, 'r') as f:
        chiplet = f.read()
        chiplet = chiplet.replace(".inc 'duo_core1_vdd_decap_dcap10.param'", ".inc '" + str(os.getpid()) + "_duo_core1_vdd_decap_dcap10.param'")
        #chiplet = chiplet.replace('*id_power',p)


        f.close()
    with open(PATH_PREFIX + str(os.getpid()) + '_' + filename, 'w') as f:
        f.write(chiplet)
        f.close()
    # recreate
    filename1 = 'int1_tr_core1_dcap10.sp'
    with open(PATH_PREFIX + filename1, 'r') as f:
        chiplet = f.read()
        chiplet = chiplet.replace(".include 'duo_tr_core1_dcap10.subckt'",
                                  ".include '" + str(os.getpid()) + "_duo_tr_core1_dcap10_%d.subckt' " % subs )
        f.close()
    with open(PATH_PREFIX + str(os.getpid()) + '_' + filename1, 'w') as f:
        f.write(chiplet)
        f.close()
    # add pid to the linux command
    os.system(
        'ngspice -b ' + str(os.getpid()) + '_int1_tr_core1_dcap10.sp -r ' + str(os.getpid()) + '_interposer1_tr.raw')
    os.system('bin/inttrvmap int1.conf ' + str(os.getpid()) + '_interposer1_tr.raw 1.2 0.12 ' + str(os.getpid()))
    #ST += 1

def readvdi(file):  # 读取csv中的vdi的数据，得到的是array数据，这里作为input
    zvdi = readresult(file)
    z = zvdi[:, 2]
    return z


def readresult(filename):
    a1 = np.genfromtxt(filename)
    return a1



class DecapPlaceParallel(gym.Env):
    metadata = {'render.modes': ['human']}

    def __init__(self, env_config):
        self.env_steps = 0  
        # stay, left, up, right, down = 0, 1, 2, 3, 4
        #self.st = 0
        self.action_meaning = [0, 2, -1]
        self.vdi_min = 0
        self.vdi_max = 0
        self.action_space = spaces.Tuple([spaces.Discrete(len(self.action_meaning))]*NCAP )      # need to add cap value
        low_space=np.array([VDI_LOW] * (NCOL * NROW )).reshape(5,5)
        high_space =np.array([VDI_HIGH] * (NCOL * NROW )).reshape(5,5) 
        self.observation_space = spaces.Box(
            low = low_space  ,
            high = high_space  , dtype=np.float64)

        # initialize current param/spec observations
        self.cur_params_idx = np.zeros(NCAP, dtype=np.int32)
        self.init_vdi = None
        self.target_vdi=0
        # Get the g* (overall design spec) you want to reach
        self.global_g = VDI_TARGET
        self.init = 0
           
    def reset(self):
        global vdi_max,vdi_min
        global dcap_offset,dcap_threshold 
        global dcap_max,dcap_min


        if self.env_steps ==0:
            s1 = ''
            for i in range(NCAP):
                s1 += '.param dcap_%d_val=0\n' % i
            f = open(PATH_PREFIX + str(os.getpid()) + '_duo_core1_vdd_decap_dcap10.param', 'w')
            f.write(s1)
            f.close()
            run_os()
            state0 = readvdi(PATH_PREFIX + str(os.getpid()) + '_duo_vdd_1_vdi.csv')
            state1 = np.array(state0)
            state2 = np.concatenate((state1[91:96],state1[103:108],state1[115:120],state1[127:132],state1[139:144]))
            self.init_vdi = state2
            self.vdi_max = np.sum(self.init_vdi)
            
            self.target_vdi = 0.05*np.sum(self.init_vdi)

            s2 = ''
            for j in range(NCAP):
                s2 += '.param dcap_%d_val=2.1e-9\n' % j
            f = open(PATH_PREFIX + str(os.getpid()) + '_duo_core1_vdd_decap_dcap10.param', 'w')
            f.write(s2)
            f.close()
            time.sleep(1)
            run_os()
            state3 = readvdi(PATH_PREFIX + str(os.getpid()) + '_duo_vdd_1_vdi.csv')
            state4 = np.array(state3)
            state5 = np.concatenate((state4[91:96],state4[103:108],state4[115:120],state4[127:132],state4[139:144]))
            self.vdi_min = np.sum(state5)
            #vdi_min = np.sum(self.vdi_min)


        # initialize current parameters
        self.cur_params_idx = np.array([0] *NCAP)      #list
        self.cur_specs = self.update(self.cur_params_idx)       #ndarray 144        current VDI distribution  shape 25
        cur_spec_norm = self.lookup(self.cur_specs, 0.05*self.init_vdi)  # list 144     input observation noramalization

       # reward = self.reward(self.cur_specs,0.05*self.init_vdi)
        #reward = self.reward(self.cur_specs)
        cur_spec_norm = np.array(cur_spec_norm)
        # observation is a combination of current specs distance from ideal, ideal spec, and current param vals
        print(self.cur_specs)
        print(cur_spec_norm)
        self.ob = cur_spec_norm.reshape(5,5)
        return self.ob
    

    def step(self, action):
        """
        :param action: is vector with elements between 0 and 1 mapped to the index of the corresponding parameter
        :return:
        """
        dict_exist = os.path.exists('%s_dict_state.npy' % str(os.getpid()) )
        if dict_exist:
            dict_state = np.load('%s_dict_state.npy' % str(os.getpid()) ,allow_pickle=True).item()
        else:
            dict_state = {}

        # Take action that RL agent returns to change current params
        action = list(np.reshape(np.array(action), (np.array(action).shape[0],)))
        self.cur_params_idx = self.cur_params_idx + np.array([self.action_meaning[a] for a in action])

        self.cur_params_idx = np.clip(self.cur_params_idx, [0]*NCAP , [21]*NCAP )
        # Get current specs and normalize


        #comm='''
        if (p+str(self.cur_params_idx)) in dict_state:
            self.cur_specs = dict_state[p+str(self.cur_params_idx)]
        else:
            self.cur_specs = self.update(self.cur_params_idx)   # update state=144
            dict_state[p+str(self.cur_params_idx)] = self.cur_specs
        #'''
        #self.cur_specs = self.update(self.cur_params_idx)


        cur_spec_norm = self.lookup(self.cur_specs, 0.05*self.init_vdi)  # normalize list 144
        
        #if np.sum(self.cur_params_idx) > 120:
         #   reward = -10
        #else:
        reward = self.reward(self.cur_params_idx,self.cur_specs)
        #reward = self.reward(self.cur_specs,0.05*self.init_vdi)         
        done = False
        np.save('%s_dict_state.npy'%str(os.getpid()) ,dict_state)
        
        cur_spec_norm1 = np.array(cur_spec_norm)
        self.ob = cur_spec_norm1.reshape(5,5)
        self.env_steps = self.env_steps + 1
        with open(PATH_PREFIX + str(os.getpid()) + '_' + 'cap_vdi_sum', 'a') as f:
            strs = f'no_decap:{np.sum(self.init_vdi)} V*s  add decap: sum:{np.sum(self.cur_specs)} V*s \t cap_idx:{self.cur_params_idx}\t  reward={reward} steps={self.env_steps}\n'
            #lines += strs
            f.write(strs)
            f.close()

        # print('cur ob:' + str(self.cur_specs))
        # print('ideal spec:' + str(self.specs_ideal))
        # print(reward)
               
        #return self.ob, reward, done, {},self.cur_params_idx,0.05*self.init_vdi,self.cur_specs
        return self.ob, reward, done, {}

    
    def lookup(self, spec, init_spec):

        grid_size = len(spec)  # normalized by global_vdi/grid_size
        norm_factor = np.sum(init_spec) / grid_size
        norm_spec = [ s / norm_factor for s in spec]     # shape = 144 [0,... , 2] 
        return norm_spec

    def rewardi(self, spec, goal_spec):
    
        '''
        Reward: doesn't penalize for overshooting spec, is negative
        '''
        real_specs = self.lookup(spec, goal_spec)   # normalize target/144
        pos_val = []
        reward = 0.0
        for i, rel_spec in enumerate(real_specs):
            if rel_spec > 1 :                # cur > target node
                reward -= rel_spec
                pos_val.append(0)
            else:
                pos_val.append(1)
        reward *= 0.1
        return reward    #if reward < -0.02 else 10

    def reward(self,decap_num,vdi_dis):
        global vdi_max,vdi_min
        global dcap_offset,dcap_threshold 
        global dcap_max,dcap_min

        dcap_max = 21e-9
        dcap_min = 1e-14

        vdi_max = self.vdi_max
        vdi_min = self.vdi_min
        
       # reward = 1 -np.sum(spec) / self.target_vdi
        
        vdi_total = np.sum(vdi_dis)
        dcap_total = np.sum(decap_num)*1e-10

        if vdi_total > vdi_max:
            vdi_max = vdi_total
        if vdi_total < vdi_min:
            vdi_min = vdi_total

        if dcap_total > dcap_max:
            dcap_max = dcap_total
        if dcap_total < dcap_min:
            dcap_min = dcap_total

        if (dcap_total < dcap_threshold):
            alpha = 0.0
        else:
            alpha = min(0.1+0.1*(dcap_total-dcap_offset)/dcap_threshold, 0.9)

        if (dcap_min != dcap_max and vdi_max != vdi_min):
            cost1 = alpha*(dcap_total-dcap_min)/(dcap_max-dcap_min)
            cost2 = (1.0-alpha)*(vdi_total-vdi_min)/(vdi_max-vdi_min)
            cost = -(cost1 + cost2)
        else:
            cost1 = alpha*(dcap_total-dcap_min)
            cost2 = (1.0-alpha)*(vdi_total-vdi_min)
            cost = -(cost1 + cost2 + 1.0)

        #reward = -(np.sum(spec)-self.target_vdi)/(np.sum(spec)+self.target_vdi)
        return cost   

    def update(self, params_idx):
        """

        :param action: an int between 0 ... n-1
        :return:
        """
        str_dc = ''
        #for i in range(1):
        for i,val in enumerate(params_idx):
            str_dc += '.param dcap_%d_val=%e\n' % (i,val*1e-10)
        #print(str_dc)
        f = open(PATH_PREFIX + str(os.getpid()) + '_duo_core1_vdd_decap_dcap10.param', 'w')
        f.write(str_dc)
        f.close()
        run_os()
        # add pid info
        state_ = readvdi(PATH_PREFIX + str(os.getpid()) + '_duo_vdd_1_vdi.csv')
        state1 = np.array(state_)
        state2 = np.concatenate((state1[91:96],state1[103:108],state1[115:120],state1[127:132],state1[139:144]))
        return state2


def main():
    env_config = {}
    env = DecapPlaceParallel(env_config)
    
    env.reset()
    env.step([2]*NCAP)

    IPython.embed()


if __name__ == "__main__":
    print(os.getpid())
    main()
    
