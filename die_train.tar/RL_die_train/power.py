import random
import numpy as np
node_loc = [416,1250,2083,2916,3750,4583,5416,6250,7083,7916,8750,9583]
f = open('power_source','w')
st = ''
for i in range(15):
    a,b = random.randint(0,11),random.randint(0,11)
    c = a*12 + b
    t1 = round(random.uniform(1.,8.),3)
    t2 = round(t1+0.5,3)
    peak = round(random.random(),3)
    hold = random.uniform(0.7,1.3)
    t3 = round(t1+hold,3)
    t4 = round(t2+hold,3)
    s = f'id_0_0_0_{c} nd_1_0_{node_loc[b]}_{node_loc[a]} 0 pwl(0 0.0 {t1}e+00ns 0.0 {t2}e+00ns'\
            f' {peak} {t3}e+00ns {peak} {t4}e+00ns 0.0)\n'
    st += s
f.write(st)
f.close()
